from setuptools import setup

setup(
    name="tvt",
    version="1.1",
    url="",
    license="MIT",
    author="LordShen",
    author_email="",
    description="cool library",
    platforms=["any"],
)
